 docker build -t csvfile .
docker run --rm --network="host" csvfile