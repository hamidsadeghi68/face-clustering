# This code is an unoptimized implementation of face clustering
# for FaceCup challenge via insightface and sklearn python packages
# based on FaceCup sample code.
#
# Enter your username and password in data dictionary,
# and create .zip file file to use in FaceCup challenge.
#
# Good luck! :D
# Hamid Sadeghi
# github.com/hamidsadeghi68
#

# -------------------------------------------------------------------------------------------------
# ------------- IMPORTANT: Replace your_username and your_password by true values here ------------
data = {
    "username": "your_username",
    "password": "your_password"
}

# -------------------------------------------------------------------------------------------------
import cv2
import requests
import numpy as np
import pandas as pd
from sklearn import cluster
from insightface.app import FaceAnalysis


s = requests.Session()
# Local Test
# gallery_directory = "http://localhost/gallery/"
# facecup upload
gallery_directory = "http://image.facecup/gallery/"
gallery_images_names = s.get(gallery_directory + 'images.txt').text.split()


# -------------------------------------------------------------------------------------------------
# --------------- Face detection and feature/template/embedding/encoding extraction ---------------
app = FaceAnalysis(name='buffalo_sc', root='./utils') # use fast models in buffalo_sc
app.prepare(ctx_id=0)

features = []
rejected_files = []
accepted_files = []
for image_name in gallery_images_names:
    if image_name.split('.')[1] == 'txt':
        continue
    resp = s.get(gallery_directory + image_name)
    image = np.asarray(bytearray(resp.content), dtype="uint8")
    img = cv2.imdecode(image, cv2.IMREAD_COLOR)
    if img is not None:
        faces = app.get(img) # insightface feature extraction
        if len(faces) > 0:
            features.append(faces[0].normed_embedding)
            accepted_files.append(image_name)
        else:
            rejected_files.append(image_name)


# -------------------------------------------------------------------------------------------------
# ---------------------------------- Clustering on the features -----------------------------------
y_pred = cluster.AgglomerativeClustering(n_clusters=None, distance_threshold=1.0,
                                         linkage='single').fit_predict(features)


# -------------------------------------------------------------------------------------------------
# ------------------------ produce csv file according to the FaceCup rules ------------------------

# produce clustering label for the rejected images:
y_pred_complete = np.array(list(y_pred) +
                           list(range(max(y_pred) + 1, max(y_pred) + len(rejected_files) + 1)))

# to avoid 0 in output labels
y_pred_complete += 1

# sort the output via file names:
file_names = np.array(accepted_files + rejected_files)
indices = np.argsort(file_names)
file_names = file_names[indices[:]]
y_pred_complete = y_pred_complete[indices[:]]

# save the output as a csv file:
image_names_and_labels = np.concatenate((np.matrix(file_names), np.matrix(y_pred_complete).astype(np.int32)))
final_csv = pd.DataFrame(np.array(image_names_and_labels.transpose()))
final_csv.to_csv('TeamNameClustering.csv', sep=',', index=False, header=False)
files = {"csv": open("TeamNameClustering.csv", 'rb')}


# -------------------------------------------------------------------------------------------------
# -------------------------------- post the output for evaluation ---------------------------------
url = "https://api.facecup.ir/api/get_csv/"
response = requests.post(url=url, data=data, files=files)
print(response)


